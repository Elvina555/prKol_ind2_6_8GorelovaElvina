﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Kol_ind2_6
{
    class Program
    {
        class Cotrydniki
        {
            public string familia;
            public string name;
            public string otestvo;
            public string pol;
            public int voz;
            public double zp;
        }
        static void Main(string[] args)
        {
            try
            {
                if (File.Exists("file1.txt"))
                {
                    Queue<Cotrydniki> a = new Queue<Cotrydniki>();
                    string[] file = File.ReadAllLines("file1.txt");
                    if (file.Length != 0)
                    {
                        foreach (var man in file)
                        {
                            Cotrydniki cot = new Cotrydniki();
                            string[] b = man.Split(' ');
                            if (int.Parse(b[4]) < 15 || int.Parse(b[4]) > 71)
                            {
                                Console.WriteLine("Введите возраст от 14 до 70");
                                Console.ReadKey();
                                return;
                            }
                            if (double.Parse(b[5]) < 0)
                            {
                                Console.WriteLine("Зарплата сотрудников не может меньше 0");
                                Console.ReadKey();
                                return;
                            }
                            cot.familia = b[0];
                            cot.name = b[1];
                            cot.otestvo = b[2];
                            cot.pol = b[3];
                            cot.voz = int.Parse(b[4]);
                            cot.zp = double.Parse(b[5]);
                            a.Enqueue(cot);
                        }
                        var firma = from man in a
                                             where man.pol.ToLower().Contains("мужской")
                                             select man;
                        foreach (var man in firma)
                        {
                            Console.Write($"{man.familia} {man.name} {man.otestvo} {man.pol} {man.voz} {man.zp}\n");
                        }

                        var firma1 = from man in a
                                              where man.pol.ToLower().Contains("женский")
                                              select man;
                        foreach (var man in firma1)
                        {
                            Console.Write($"{man.familia} {man.name} {man.otestvo} {man.pol} {man.voz} {man.zp}\n");
                        }
                    }
                    else
                        Console.WriteLine("Файл пуст");
                }
                else
                    Console.WriteLine("Файл не найден");
            }
            catch
            {
                Console.WriteLine("Введите корректно");
            }
            Console.ReadKey();
        }
    }
}
