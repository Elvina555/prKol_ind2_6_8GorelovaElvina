﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind2_8
{
    public partial class Form1 : Form
    {
        Queue<Cotrydniki> a = new Queue<Cotrydniki>();
        public Form1()
        {
            InitializeComponent();
        }
        class Cotrydniki
        {
            public string familia;
            public string name;
            public string otestvo;
            public string pol;
            public int voz;
            public double zp;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("file2.txt"))
                {
                    listBox2.Items.Clear();

                    var firma = from man in a
                                         where man.voz < 30
                                         select man;
                    foreach (var man in firma)
                    {
                        listBox2.Items.Add($"{man.familia} {man.name} {man.otestvo} {man.pol} {man.voz} {man.zp}\n");
                    }

                    var firma1 = from man in a
                                          where man.voz >= 30
                                          select man;
                    foreach (var man in firma1)
                    {
                        listBox2.Items.Add($"{man.familia} {man.name} {man.otestvo} {man.pol} {man.voz} {man.zp}\n");
                    }
                }
                else
                    MessageBox.Show("Файл не найден");
            }
            catch
            {
                MessageBox.Show("Введите ккоректно");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("file2.txt"))
                {
                    string[] file = File.ReadAllLines("file2.txt");
                    if (file.Length != 0)
                    {
                        foreach (var man in file)
                        {
                            Cotrydniki cot = new Cotrydniki();
                            string[] b = man.Split(' ');
                            if (double.Parse(b[4]) > 15 && double.Parse(b[4]) <71)
                            {
                                if (double.Parse(b[5]) >= 0)
                                {
                                    cot.familia = b[0];
                                    cot.name = b[1];
                                    cot.otestvo = b[2];
                                    cot.pol = b[3];
                                    cot.voz = int.Parse(b[4]);
                                    cot.zp = double.Parse(b[5]);
                                    a.Enqueue(cot);
                                    listBox1.Items.Add($"{cot.familia} {cot.name} {cot.otestvo} {cot.pol} {cot.voz} {cot.zp}");
                                }
                                else
                                {
                                    MessageBox.Show("Зарплата сотрудника не может быть меньше нуля");
                                    Application.Exit();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Введите возраст от 14 до 70");
                                Application.Exit();
                            }
                        }
                    }
                    else
                        MessageBox.Show("Файл пуст");
                }
                else
                    MessageBox.Show("Файл не найден");
            }
            catch
            {
                MessageBox.Show("Введите корректно");
            }
        }
    }
}
